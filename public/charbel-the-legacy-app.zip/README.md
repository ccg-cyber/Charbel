# Charbel "The Legacy" Geagea (#22) - Official Champs App

A responsive player profile and 9:16 WhatsApp Status poster application celebrating Charbel Geagea's championship victory (Champs 47 - 25 A Team, September 19, 2026).

## Quick Start

1. Install dependencies:
```bash
npm install
```

2. Run development server:
```bash
npm run dev
```

3. Build for production:
```bash
npm run build
```

## Features
- **Player Biography & Creed**: Dedicated profile honoring Charbel's mental discipline, court vision, and selfless leadership.
- **Matchday Victory Scoreboard**: Full recap of the 47 - 25 win over A Team with quarter-by-quarter scoring.
- **9:16 WhatsApp Status Studio**: Export 1080×1920 status cards with custom filters and quotes.
- **Photo Upload**: Load any real match photo of Charbel.
- **Mobile Responsive**: Fully tuned for Samsung, iPhone, and Android devices.
